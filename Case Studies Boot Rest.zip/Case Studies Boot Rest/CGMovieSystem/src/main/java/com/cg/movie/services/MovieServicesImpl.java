package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.daoservices.MovieDAO;
import com.cg.movie.daoservices.SongDAO;
import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.exceptions.SongNotFoundException;

@Component
public class MovieServicesImpl implements MovieServices {

	@Autowired
	MovieDAO movieDao;
	
	@Autowired
	SongDAO songDao;
	
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		return movieDao.save(movie);
	}

	@Override
	public Movie getMovieDetails(int movieId) throws MovieNotFoundException{
		
		return movieDao.findById(movieId).orElseThrow(()-> new MovieNotFoundException("Movie not found "));
	}

	@Override
	public Song acceptSongDetails(Song song) {
		
	return songDao.save(song);
	}

	@Override
	public Song getSongDetails(int songId) throws SongNotFoundException {
		
		return songDao.findById(songId).orElseThrow(()-> new SongNotFoundException("Song Not Found"));
	}

	@Override
	public List<Song> getAllSongDetails(int movieId) {
		return songDao.findAllMovieSongs(movieId);
		
	}

	

}
