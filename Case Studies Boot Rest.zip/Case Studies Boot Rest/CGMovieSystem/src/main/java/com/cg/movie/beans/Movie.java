package com.cg.movie.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int movieId;
	private String movieName;
	private String producer;
	
	@OneToMany(mappedBy="movie")
	private List<Song> songs;

	public Movie(){}
	
	public Movie(String movieName, String producer, List<Song> songs) {
		super();
		this.movieName = movieName;
		this.producer = producer;
		this.songs = songs;
	}

	public Movie(int movieId, String movieName, String producer, List<Song> songs) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.producer = producer;
		this.songs = songs;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getProducer() {
		return producer;
	}

	public void setProducer(String producer) {
		this.producer = producer;
	}

	public List<Song> getSongs() {
		return songs;
	}

	public void setSongs(List<Song> songs) {
		this.songs = songs;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", producer=" + producer + ", songs=" + songs
				+ "]";
	}
	
	
}
