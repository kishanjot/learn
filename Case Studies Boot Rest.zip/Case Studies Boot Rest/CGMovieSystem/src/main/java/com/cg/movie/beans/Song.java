package com.cg.movie.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Song {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int songId;
	private String songName;
	private String singer;
	
	@JsonIgnore
	@OneToOne
	private Movie movie;

	public Song(){}
	
	public Song(String songName, String singer, Movie movie) {
		super();
		this.songName = songName;
		this.singer = singer;
		this.movie = movie;
	}

	public Song(int songId, String songName, String singer, Movie movie) {
		super();
		this.songId = songId;
		this.songName = songName;
		this.singer = singer;
		this.movie = movie;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	@Override
	public String toString() {
		return "Song [songId=" + songId + ", songName=" + songName + ", singer=" + singer + ", movie=" + movie + "]";
	}

	
}
