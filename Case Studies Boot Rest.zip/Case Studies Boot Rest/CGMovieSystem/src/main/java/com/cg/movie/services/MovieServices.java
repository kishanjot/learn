package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.exceptions.SongNotFoundException;

public interface MovieServices {

public Movie acceptMovieDetails(Movie movie);
public Movie getMovieDetails(int movieId) throws MovieNotFoundException; 
public Song acceptSongDetails(Song song); 
public Song getSongDetails(int songId) throws SongNotFoundException;

public List<Song> getAllSongDetails(int movieId);

}
