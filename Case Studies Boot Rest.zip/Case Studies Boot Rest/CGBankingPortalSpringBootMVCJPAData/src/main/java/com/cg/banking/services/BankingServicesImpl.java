package com.cg.banking.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;

import com.cg.banking.daoservices.TransactionDAO;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component("bankingServices")
public class BankingServicesImpl implements BankingServices{
	
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	
		
   // Transaction transaction;
	//Account account;
	//Account account1;
	public static HashMap<Integer,Transaction> transactions;

	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		

			if ((account.getAccountType().equalsIgnoreCase("Savings")) || (account.getAccountType().equals("current")))
			{
			account=new Account(account.getAccountType(),account.getAccountBalance());
			//int pin=(int)(Math.random()*10000);//newly added for random pin
			//account.setPinNumber(pin);
			account.setPinNumber((int)(Math.random()*10000));
			accountDAO.save(account);
			account.getAccountStatus();
			}
			else
				throw new InvalidAccountTypeException("Invalid type");
			return account;
		}
	
	
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Transaction transaction;
		Account account=accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account not found"));
		
		account.setAccountBalance(account.getAccountBalance()+amount);
		 transaction=new Transaction(amount,"Deposit",account);
		transaction=transactionDAO.save(transaction);
		
               
return amount;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		
		Transaction transaction;
		Account account;
		
		account=accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Acc Not Found"));
		
		if(account.getPinNumber()==pinNumber){
		if(amount>account.getAccountBalance())
			throw new InsufficientAmountException();
		else{
		account.setAccountBalance(account.getAccountBalance()-amount);
		 transaction=new Transaction(amount,"Withdraw",account);
		 transactionDAO.save(transaction);
		 accountDAO.save(account); //accountnolink to transaction table
		}
	}
		else {
			throw new InvalidPinNumberException();
			}
	  return amount;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException,
		BankingServicesDownException, AccountBlockedException {
		Transaction transaction;
		Account account1;
		Account account;
		
			account=accountDAO.findById(accountNoFrom).orElseThrow(()-> new AccountNotFoundException("AccountNotFOund"));
			account1=accountDAO.findById(accountNoTo).orElseThrow(()-> new AccountNotFoundException("AccountNotFOund"));
				if(account==null || account1==null)
				{
					throw new AccountNotFoundException("Please enter valid account number");
				}
				else {
				if(account.getPinNumber()==pinNumber)
				{
				if(transferAmount>account.getAccountBalance())
					throw new InsufficientAmountException();
				else
				account.setAccountBalance(account.getAccountBalance()-transferAmount);
				account1.setAccountBalance(account1.getAccountBalance()+transferAmount);
				 transaction=new Transaction(transferAmount,"Transfer",account);
				 transactionDAO.save(transaction);
				
				}
				else
					throw new InvalidPinNumberException();
				}
				return true;
	}


	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account;
		account= accountDAO.findById(accountNo).orElseThrow(()-> new AccountNotFoundException("Not Found"));
		
		return account;
	}


	/*public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}*/

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
	
	return null; //transactionDAO.findAll(accountNo).orElseThrow(()->new AccountBlockedException("Blocked"));
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account= accountDAO.findById(accountNo).orElseThrow(()->new AccountNotFoundException("not found"));
		return account.getAccountStatus();
	}


	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
