//Exception Class

package com.cg.product.exceptions;

public class ProductNotFoundInDatabaseException extends Exception{

	public ProductNotFoundInDatabaseException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductNotFoundInDatabaseException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFoundInDatabaseException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFoundInDatabaseException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ProductNotFoundInDatabaseException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}



}
