package com.cg.product.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundInDatabaseException;
import com.cg.product.services.IProductService;
@Controller
public class ProductController {
	@Autowired
	private IProductService services;
	 @RequestMapping(value="/acceptProdDetails",method=RequestMethod.POST, 
				consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		 Product productId=services.createProduct(product);
			return new ResponseEntity<>("Product details added :- "+productId,HttpStatus.OK);
		}
	 @PutMapping(value= {"/products/{Id}"},headers="Accept=application/json")
		public ResponseEntity<Product> updateDetailsPathParam(@PathVariable(value="Id") @RequestBody Product product) throws ProductNotFoundInDatabaseException{
			product=services.updateProduct(product);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
   } 
	 @RequestMapping(value= {"/getProdDetails/{productId}"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<Product> getProductDetailsPathParam(@PathVariable(value="productId") String productId) throws ProductNotFoundInDatabaseException{
			Product product=services.findProduct(productId);
			return new ResponseEntity<Product>(product,HttpStatus.OK);
} 
	 @RequestMapping(value="/deleteProd/{productId}",method=RequestMethod.DELETE,
				consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
		public ResponseEntity<String> removeProductDetails(@PathVariable(value="productId") String productId) throws ProductNotFoundInDatabaseException{
			services.deleteProduct(productId);
			return new ResponseEntity<>("Product removed",HttpStatus.OK);
		}
	 @RequestMapping(value= {"/products"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
		public ResponseEntity<List<Product>> getproductDetailsRequestParam(){
			List<Product> products=services.viewProducts();
			return new ResponseEntity<List<Product>>(products,HttpStatus.OK);
		}
}
