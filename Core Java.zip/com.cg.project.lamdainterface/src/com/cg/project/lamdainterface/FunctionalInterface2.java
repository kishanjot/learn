package com.cg.project.lamdainterface;
@FunctionalInterface
public interface FunctionalInterface2 {
	public String add(String a,String b);
}
