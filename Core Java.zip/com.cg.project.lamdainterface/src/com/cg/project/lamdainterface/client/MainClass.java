package com.cg.project.lamdainterface.client;
import com.cg.project.lamdainterface.FunctionalInterface1;
import com.cg.project.lamdainterface.FunctionalInterface2;
public class MainClass {
	public static void main(String[] args) {
	/*	FunctionalInterface1 ref1 =(firstName,lastname) -> {
			System.out.println("Hello "+firstName+" "+lastname);
		};		
		ref1.greetuser("Somnath", "Dey");
	}*/	
		FunctionalInterface2 ref2 = (String num1,String num2) -> num1+num2;
		System.out.println(ref2.add("A","B"));	
}
}

