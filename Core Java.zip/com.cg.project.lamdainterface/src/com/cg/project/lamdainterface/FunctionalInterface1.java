package com.cg.project.lamdainterface;

@FunctionalInterface
public interface FunctionalInterface1 {
	void greetuser(String firstName,String lastname);
}
