package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOimpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public class PayrollServicesimpl implements PayrollServices{
	private AssociateDAO associatedao= new AssociateDAOimpl();
	
	private static final Logger logger = Logger.getLogger(PayrollServicesimpl.class);
	
	public int acceptAssociateDetails(String firstName, String lastNmae, String email, String department,
			String designation, String pancard, int yearlyInvestment, int basicSalary, int epf, int companypf,
			int accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException {
		try {
			Associate associate=new Associate(yearlyInvestment, firstName, lastNmae, department, designation, pancard, email, new BankDetail(accountNumber, bankName, ifscCode),new Salary(basicSalary, epf, companypf));
			associate=associatedao.save(associate);
			return associate.getAssociateId();
		} catch (SQLException e) {
			logger.error(e.getMessage()+""+e.getCause()+""+e.getErrorCode());
			throw new PayrollServicesDownException("Service unavailable1");
		}	
}
	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFound, PayrollServicesDownException {
		Associate associate;
		try {
			associate = associatedao.findOne(associateId);
			if(associate==null) throw new AssociateDetailsNotFound("Associate Details Not Found");
		} catch (SQLException e) {
			throw new PayrollServicesDownException("Services unavailable");
		}

		//tax calculation code
		int basicSalary=associate.getSalary().getBasicSalary();

		int hra=50*basicSalary/100;
		associate.getSalary().setHra(hra);

		int conveyenceAllowance=25*basicSalary/100;
		associate.getSalary().setConveyenceAllowance(conveyenceAllowance);

		int otherAllowance=25*basicSalary/100;
		associate.getSalary().setOtherAllowance(otherAllowance);

		int personalAllowance=40*basicSalary/100;
		associate.getSalary().setPersonalAllowance(personalAllowance);

		/*int epf=12*basicSalary/100;*/
		int epf= associate.getSalary().getEpf();

/*		int companyPf = 12*basicSalary/100;*/
		associate.getSalary().getCompanyPf();

		int gratuity=481*basicSalary/10000;
		associate.getSalary().setGratuity(gratuity);

		int grossSalary=basicSalary+conveyenceAllowance+otherAllowance+personalAllowance+epf;
		associate.getSalary().setGrossSalary(grossSalary);
		int yearlyInvestmentUnder80C = associate.getYearlyInvestmentUnder80C();
		if(yearlyInvestmentUnder80C+epf+associate.getSalary().getCompanyPf()>150000)
			yearlyInvestmentUnder80C=150000-epf-associate.getSalary().getCompanyPf();
		associate.setYearlyInvestmentUnder80C(yearlyInvestmentUnder80C);

		int taxableIncome = 12*(grossSalary-epf)-yearlyInvestmentUnder80C;
		int yearlyTax=0;
		if(taxableIncome<=250000)
			yearlyTax=0;
		else if(taxableIncome>250000 && taxableIncome<=500000)
			yearlyTax=5*(taxableIncome-250000)/100;
		else if(taxableIncome>500000 && taxableIncome<=1000000)
			yearlyTax=12500+20*(taxableIncome-500000);
		else
			yearlyTax=112500+30*(taxableIncome-1000000);
		int monthlyTax=yearlyTax/12;
		associate.getSalary().setMonthlyTax(monthlyTax);

		int netSalary=grossSalary-epf-monthlyTax;
		associate.getSalary().setNetSalary(netSalary);
		
		try {
			associatedao.update(associate);
		} catch (SQLException e) {
			throw new PayrollServicesDownException("Services unavailable");
		}
		return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFound, PayrollServicesDownException {
		Associate associate;
		try {
			associate = associatedao.findOne(associateId);
			if(associate==null)throw new AssociateDetailsNotFound("Associate Details not found");
			return associate;
		} catch (SQLException e) {
			throw new PayrollServicesDownException("Services unavailable3");
		}
	}
	@Override
	public  ArrayList<Associate> getAllAssociatesDetails() throws PayrollServicesDownException{
		try {
			return associatedao.findsAll();
		} catch (SQLException e) {
			throw new PayrollServicesDownException("Services unavailable4");
		}
	}	
}
