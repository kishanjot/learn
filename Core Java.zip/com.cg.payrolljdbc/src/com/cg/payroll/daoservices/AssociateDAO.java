package com.cg.payroll.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
public interface AssociateDAO {
	Associate save(Associate associate)throws SQLException;
	boolean update(Associate associate) throws SQLException,AssociateDetailsNotFound;
	Associate findOne(int associateId) throws SQLException;
	ArrayList<Associate> findsAll() throws SQLException;
}
