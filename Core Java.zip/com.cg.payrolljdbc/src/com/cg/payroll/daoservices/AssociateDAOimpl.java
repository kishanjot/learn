package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.util.ConnectionProvider;
public class AssociateDAOimpl implements AssociateDAO{
	private Connection conn = ConnectionProvider.getDBConnection();
	@Override
	public Associate save(Associate associate) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1= conn.prepareStatement("insert into Associate values(sequence_associateID.nextval,?,?,?,?,?,?,?)");
			//pstmt1.setInt(1,associate.getAssociateId());
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();	
			
			PreparedStatement pstmt2= conn.prepareStatement("select max(associateID) from Associate");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateID = rs.getInt(1);	
			
			PreparedStatement pstmt3 = conn.prepareStatement("insert into BankDetails values(?,?,?,?)");
			pstmt3.setInt(1, associateID);
			pstmt3.setInt(2, associate.getBankDetails().getAccountNumber());
			pstmt3.setString(3, associate.getBankDetails().getBankName());
			pstmt3.setString(4, associate.getBankDetails().getIfscCode());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = conn.prepareStatement("insert into Salary(associateID,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt4.setInt(1, associateID);
			pstmt4.setInt(2, associate.getSalary().getBasicSalary());
			pstmt4.setInt(3, associate.getSalary().getEpf());
			pstmt4.setInt(4, associate.getSalary().getCompanyPf());
			pstmt4.executeUpdate();
			associate.setAssociateId(associateID);
			conn.commit();
		return associate;
		}catch(SQLException e){
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
	}
		
	

	@Override
	public Associate findOne(int associateId) throws SQLException {
	PreparedStatement pstmt1 = conn.prepareStatement("Select * from Associate where associateID ="+associateId);
	ResultSet associateRS = pstmt1.executeQuery();
	if(associateRS.next()){
		String firstName = associateRS.getString("firstName");
		String lastName = associateRS.getString("lastName");
		String department = associateRS.getString("department");
		String designation = associateRS.getString("designation");
		String pancard = associateRS.getString("pancard");
		String emailId = associateRS.getString("emailId");
		int yearlyInvestmentUnder80C = associateRS.getInt("yearlyInvestmentUnder80C");
		Associate associates = new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
		
		PreparedStatement pstmt2=conn.prepareStatement("Select * from bankDetails where associateID="+associateId);
		ResultSet bankdetailsRs =pstmt2.executeQuery();
		bankdetailsRs.next();
		int accountNumber=bankdetailsRs.getInt("accountNumber");
		String bankName=bankdetailsRs.getString("bankName");
		String ifscCode = bankdetailsRs.getString("ifscCode");
		associates.setBankDetails(new BankDetail(accountNumber, bankName, ifscCode));
		
		PreparedStatement pstmt3 = conn.prepareStatement("Select * from Salary where associateID="+associateId);
		ResultSet salaryRS=pstmt3.executeQuery();
		salaryRS.next();
		associates.setSalary(new Salary(salaryRS.getInt("basicSalary"), salaryRS.getInt("hra"),salaryRS.getInt("conveyenceAllowance"), salaryRS.getInt("otherAllowance"),salaryRS.getInt("MonthlyTax"),salaryRS.getInt("personalAllowance"), salaryRS.getInt("epf"),salaryRS.getInt("companyPf"),salaryRS.getInt("gratuity"), salaryRS.getInt("grossSalary"), salaryRS.getInt("netSalary") ));
		
		return associates;
	}
			return null;
	}

	@Override
	public ArrayList<Associate> findsAll() throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from Associate");
		ResultSet associateRS =pstmt1.executeQuery();
		
		ArrayList<Associate> associates = new ArrayList<>();
		while(associateRS.next()){
			int associateId = associateRS.getInt("associateId");
			int yearlyInvestmentUnder80C = associateRS.getInt("yearlyInvestmentUnder80C");
			String firstName = associateRS.getString("firstName");
			String lastName = associateRS.getString("lastName");
			String department = associateRS.getString("department");
			String designation = associateRS.getString("designation");
			String pancard = associateRS.getString("pancard");
			String emailId = associateRS.getString("emailId");
			
			
			Associate associate = new Associate(associateId, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
			
			PreparedStatement pstmt2=conn.prepareStatement("Select * from bankDetails");
			ResultSet bankdetailsRs =pstmt2.executeQuery();
			bankdetailsRs.next();
			int accountNumber=bankdetailsRs.getInt("accountNumber");
			String bankName=bankdetailsRs.getString("bankName");
			String ifscCode = bankdetailsRs.getString("ifscCode");
			associate.setBankDetails(new BankDetail(accountNumber, bankName, ifscCode));
		
			PreparedStatement pstmt3 = conn.prepareStatement("Select * from Salary");
			ResultSet salaryRS=pstmt3.executeQuery();
			salaryRS.next();
			associate.setSalary(new Salary(salaryRS.getInt("basicSalary"), salaryRS.getInt("hra"),salaryRS.getInt("conveyenceAllowance"), salaryRS.getInt("otherAllowance"),salaryRS.getInt("MonthlyTax"),salaryRS.getInt("personalAllowance"), salaryRS.getInt("epf"),salaryRS.getInt("companyPf"),salaryRS.getInt("gratuity"), salaryRS.getInt("grossSalary"), salaryRS.getInt("netSalary") ));	
		}
		for (Associate associate : associates) {
			System.out.println(associate);
		}
		return associates;
	}

	@Override
	public boolean update(Associate associate) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("update salary set basicSalary=? ,hra=? ,conveyenceAllowance=? ,otherAllowance =?,personalAllowance=?,monthlyTax=?, epf=? ,companyPf=? ,gratuity=? ,grossSalary=? ,netSalary=? where associateId=?");
		pstmt1.setInt(1, associate.getSalary().getBasicSalary());
		pstmt1.setInt(2, associate.getSalary().getHra());
		pstmt1.setInt(3, associate.getSalary().getConveyenceAllowance());
		pstmt1.setInt(4, associate.getSalary().getOtherAllowance());
		pstmt1.setInt(5, associate.getSalary().getPersonalAllowance());
		pstmt1.setInt(6, associate.getSalary().getMonthlyTax());
		pstmt1.setInt(7, associate.getSalary().getEpf());
		pstmt1.setInt(8, associate.getSalary().getCompanyPf());
		pstmt1.setInt(9, associate.getSalary().getGratuity());
		pstmt1.setInt(10, associate.getSalary().getGrossSalary());
		pstmt1.setInt(11, associate.getSalary().getNetSalary());
		pstmt1.setInt(12, associate.getAssociateId());
		pstmt1.executeUpdate();
		conn.commit();
		return false;
	}
	
}
