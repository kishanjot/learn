package com.cg.inheritance;

public final class CEmployee extends Employee {
		private int noOfHrs, variablePay;
		
		public CEmployee() {
			super();
		}

		public CEmployee(int employeeId, String firstName, String lastName,
				int basicSalary) {
			super(employeeId, firstName, lastName, basicSalary);
		}

		public int getNoOfHrs() {
			return noOfHrs;
		}
		public void setNoOfHrs(int noOfHrs) {
			this.noOfHrs = noOfHrs;
		}
		public int getVariablePay() {
			return variablePay;
		}
		public void setVariablePay(int variablePay) {
			this.variablePay = variablePay;
		}

		@Override
		public void CalculateTotalSalary() {
			noOfHrs=500;
			variablePay=1000;
			this.setTotalSalary(noOfHrs*variablePay);
		}

		@Override
		public String toString() {
			return super.toString()+ "noOfHrs=" + noOfHrs + ", variablePay="
					+ variablePay ;
		}
}
