package com.cg.inheritance.client;

import com.cg.inheritance.CEmployee;
import com.cg.inheritance.Employee;
import com.cg.inheritance.PEmployee;

public class MainClass {

	public static void main(String[] args) {
		Employee emp;
		
		emp=new PEmployee(102, "Nilesh", "Kumar", 20000);
		emp.CalculateTotalSalary();
			
		PEmployee pemp=(PEmployee) emp;
		System.out.println(pemp.getHra());
	          
		
		emp=new CEmployee(103,"Santu","Gautam",20000);
		
		emp.CalculateTotalSalary();
		System.out.println(emp.toString());	
	}
}
