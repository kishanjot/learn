package com.cg.payroll.client;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {

	public static void main(String[] args) throws PayrollServicesDownException, AssociateDetailsNotFound {
		/*
		PayrollServices payrollServices = new PayrollServicesimpl();
		int associateID=payrollServices.acceptAssociateDetails("Somnath", "Dey", "som@gmail.com", "HR", "Sr An", "CBCJ23D", 150000, 18000, 2000, 2000, 3214564, "ICICI", "icici0004");
		System.out.println(payrollServices.calculateNetSalary(associateID));
	*/
		/*Associate associate  = new Associate(101, 15000, "Somnath", "Dey", "HR", "Sr A", "CBCJ34D", "som@gmail.com", new BankDetails(101214, "ICICI", "icici001"), new Salary(15000, 1000, 1000));
		System.out.println(associate);*/
	}
}













