package com.cg.iodemo;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) throws IOException {

		File fileFrom = new File("D:\\DataFile.txt");
		File fileTo = new File("D:\\FileReadWrite"+fileFrom.getName());
		IOClassesDemo.byteStreamreadWrite(fileFrom, fileTo);
	}
}
