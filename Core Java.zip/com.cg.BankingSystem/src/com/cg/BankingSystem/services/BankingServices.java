package com.cg.BankingSystem.services;

import java.util.List;

import com.cg.BankingSystem.Exceptions.AccountBlockedException;
import com.cg.BankingSystem.Exceptions.AccountNotFoundException;
import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.Exceptions.InsufficientAmountException;
import com.cg.BankingSystem.Exceptions.InvalidAccountTypeException;
import com.cg.BankingSystem.Exceptions.InvalidAmountException;
import com.cg.BankingSystem.Exceptions.InvalidPinNumberException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;


public interface BankingServices {

	long openAccount(String accountType,float initBalance)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;

	float depositAmount(long accountNo,float amount)
			throws
			AccountNotFoundException,BankingServicesDownException, AccountBlockedException;

	float withdrawAmount(long accountNo,float amount,int pinNumber)
			throws InsufficientAmountException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException;

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException  ;

	Account getAccountDetails(long accountNo)
			throws  AccountNotFoundException,BankingServicesDownException;

	List<Account> getAllAccountDetails()
			throws BankingServicesDownException;

	List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException;

	public String accountStatus(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException, AccountBlockedException;
}