package com.cg.BankingSystem.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.BankingSystem.Exceptions.AccountBlockedException;
import com.cg.BankingSystem.Exceptions.AccountNotFoundException;
import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.Exceptions.InsufficientAmountException;
import com.cg.BankingSystem.Exceptions.InvalidAccountTypeException;
import com.cg.BankingSystem.Exceptions.InvalidAmountException;
import com.cg.BankingSystem.Exceptions.InvalidPinNumberException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;
import com.cg.BankingSystem.daoservices.AccountDAO;
import com.cg.BankingSystem.daoservices.AccountDAOImpl;

public class BankingServicesImpl implements BankingServices{
	AccountDAO accountdao = new AccountDAOImpl();

	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		try {
			Account account = new Account(accountType, initBalance);
			account = accountdao.save(account);
			account.setAccountBalance(initBalance);
			accountdao.update(account); 
			return account.getAccountNo();
		} catch (SQLException e) {
			throw new BankingServicesDownException("Services Unavailable");
		}
}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException {
		try {
			Account account =  accountdao.findOne(accountNo);
			account.setAccountBalance(amount+account.getAccountBalance());
			accountdao.update(account);

			//account.getTransaction().setTransactionType("Credited");
			accountdao.addTransaction("Credited", amount, accountNo);
			return account.getAccountBalance();	
		} catch (SQLException e) {
			throw new BankingServicesDownException("Account number dont match!!");
		}
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		try {
			Account account = accountdao.findOne(accountNo);
			if(account.getPinNumber()==pinNumber && account.getAccountBalance()>amount)				
				account.setAccountBalance(account.getAccountBalance()-amount);
			accountdao.addTransaction("Debited", amount, accountNo);
			return account.getAccountBalance();
		} catch (SQLException e) {
			throw new BankingServicesDownException("pin wrong or insufficient balance");
		}
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		try {
			Account account1 = accountdao.findOne(accountNoTo);
			Account account2 = accountdao.findOne(accountNoFrom);
			if(account2.getPinNumber()==pinNumber && account2.getAccountBalance()>transferAmount)
				account1.setAccountBalance(transferAmount+account1.getAccountBalance());
				account2.setAccountBalance(account2.getAccountBalance()-transferAmount);
				System.out.println("Transaction successful");
			
		} catch (SQLException e) {
			throw new BankingServicesDownException("Transaction Failed");
		}
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		try {
			Account account = accountdao.findOne(accountNo);
			System.out.println(account.getPinNumber());
			return account;
		} catch (SQLException e) {
			throw new BankingServicesDownException("Account number mismatch");
		}
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		try {
			List<Account> account = accountdao.findAll();
			return account;
		} catch (SQLException e) {
			throw new BankingServicesDownException("No details present");
		}
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}

}
