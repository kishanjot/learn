package com.cg.BankingSystem.main;

import com.cg.BankingSystem.Exceptions.AccountBlockedException;
import com.cg.BankingSystem.Exceptions.AccountNotFoundException;
import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.Exceptions.InsufficientAmountException;
import com.cg.BankingSystem.Exceptions.InvalidAccountTypeException;
import com.cg.BankingSystem.Exceptions.InvalidAmountException;
import com.cg.BankingSystem.Exceptions.InvalidPinNumberException;
import com.cg.BankingSystem.connection.ConnectionProvider;
import com.cg.BankingSystem.services.BankingServices;
import com.cg.BankingSystem.services.BankingServicesImpl;

public class MainClass {

		public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		BankingServices bankservices = new BankingServicesImpl();
		System.out.println(bankservices.openAccount("Saving", 5000));
		//System.out.println(bankservices.depositAmount(21000524, 2000));
		//System.out.println(bankservices.getAccountDetails(21000524));
		//System.out.println(bankservices.getAllAccountDetails());
		System.out.println(bankservices.withdrawAmount(21000622, 1000, 8824));
	}
}
