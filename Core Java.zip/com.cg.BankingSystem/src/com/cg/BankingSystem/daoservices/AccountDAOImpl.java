package com.cg.BankingSystem.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;
import com.cg.BankingSystem.connection.ConnectionProvider;


public class AccountDAOImpl implements AccountDAO{

	private Connection conn = ConnectionProvider.getDBConnection();
	@Override
	public Account save(Account account) throws SQLException {
		try{
			int max=9999;
			int min=1000;
			conn.setAutoCommit(false);
			account.setPinNumber((int)(Math.random()*(max-min))+min);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into Account values(Seq_accountNo.nextval,?,?,?,?)");
			pstmt1.setFloat(1,account.getAccountBalance());
			pstmt1.setString(2, account.getAccountType());
			pstmt1.setString(3, "Active");
			pstmt1.setInt(4, account.getPinNumber());
			pstmt1.executeUpdate();
			conn.commit();
			PreparedStatement pstmt3 = conn.prepareStatement("Select max(accountNo) from Account");
				ResultSet rs = pstmt3.executeQuery();
				rs.next();
				long accountNo = (long) rs.getFloat(1);
				account.setAccountNo(accountNo);
				
			
			conn.commit();
			return account;
		}catch(SQLException e){
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public Account findOne(long accountNo) throws SQLException{
	
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from Account where accountNo="+accountNo);
		ResultSet rs1 = pstmt1.executeQuery();	
		if(rs1.next()){
			float accountBalance = rs1.getFloat("accountBalance");
			String accountType = rs1.getString("accountType");
			String status = rs1.getString("status");
			int pinNumber = rs1.getInt("pinNumber");
			//System.out.println(pinNumber);
			Account account = new Account(pinNumber, accountType, status, accountBalance, accountNo);
			return account;
		}
		return null;
	}

	@Override
	public boolean update(Account account) throws SQLException {
        PreparedStatement pstmt1 = conn.prepareStatement("update Account set accountBalance=? where accountNo=?");
       pstmt1.setFloat(1, account.getAccountBalance());
       pstmt1.setLong(2, account.getAccountNo());
       pstmt1.executeUpdate();
       conn.commit();
		return false;
	}

	@Override
	public List<Account> findAll() throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("select * from Account");
		ResultSet rs1 =pstmt1.executeQuery();
		List<Account> accounts = new ArrayList<Account>();
		while(rs1.next()){
			long accountNo = rs1.getLong("accountNo");
			Float accountBalance = rs1.getFloat("accountBalance");
			String accountType = rs1.getString("accountType");
			String status = rs1.getString("status");
			Account account = new Account(accountType, status, accountBalance, accountNo);
			accounts.add(account);
			}
		return accounts;
		}


	@Override
	public boolean addTransaction(String TransactionType, float amount,
			long accountNo) throws SQLException, BankingServicesDownException {
		try{
			PreparedStatement pstmt1 = conn.prepareStatement("insert into Transaction(TransactionId,TransactionType,amount,accountNo) values(Seq_transactoinId.nextval,?,?,?)");
			pstmt1.setFloat(2, amount);
			pstmt1.setString(1, TransactionType);
			pstmt1.setLong(3, accountNo);
			pstmt1.executeUpdate();
			conn.commit();
			
		}catch(SQLException e){
		throw new BankingServicesDownException("AAAAAA");
		}
		return true;
	}

	@Override
	public List<Transaction> getAllTransaction(long accountNo)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}
