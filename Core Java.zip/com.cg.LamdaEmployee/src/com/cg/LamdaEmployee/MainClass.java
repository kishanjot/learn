package com.cg.LamdaEmployee;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class MainClass {

	public static void main(String[] args) {	
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(101, 11000, "Ram"));
		empList.add(new Employee(102, 12000, "Shyam"));
		empList.add(new Employee(103, 13000, "Sita"));
		empList.add(new Employee(104, 14000, "Laxman"));
		empList.add(new Employee(105, 15000, "Shyam"));


		/*Collections.sort(empList);
		for (Employee employee : empList) {
			System.out.println(empList);
		}*/
		/*Collections.sort(empList, (emp1,emp2)->emp1.getId()-emp2.getId());
		for (Employee employee : empList) {
			System.out.println(empList);*/

		Stream<Employee> stream1 = empList.stream();
		Stream<Employee> stream2 = stream1.distinct();
		Stream<Employee> stream3 = stream2.filter(e->e.getName().startsWith("X"));
		System.out.println(stream3.count());
		long count = empList.stream()
				.distinct()
				.count();
		System.out.println((count) +" "+empList.size());
		//stream3.forEach(employee -> System.out.println(employee));


		/*	empList.stream()
		.distinct()
		.filter(e->e.getName().startsWith("N"))
		.forEach(employee -> System.out.println(employee));

		long count = empList.stream()
				.distinct()
				.count();
		System.out.println((count) +" "+empList.size());*/		

		/*		private static void method1(){
			Pattern pattern = Pattern.compile("H[abcde]");
			Matcher matcher = pattern.matcher("Hello World How Are You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}

		private static void method2(){
			Pattern pattern = Pattern.compile("\\s");
			Matcher matcher = pattern.matcher("Hello World How Are You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}

		private static void method3(){
			Pattern pattern = Pattern.compile("\\d");
			Matcher matcher = pattern.matcher("Hello World How Are You");
			while(matcher.find())
				System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		}*/
	}
}

