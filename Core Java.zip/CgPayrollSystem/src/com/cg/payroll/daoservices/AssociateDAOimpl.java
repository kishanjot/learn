package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;

public class AssociateDAOimpl implements AssociateDAO{
	public static HashMap<Integer, Associate>associates = new HashMap<>();
	//public static int Associate_IDX=0;
	public static int Associate_IDX_COUNTER=101;

	
	public Associate save(Associate associate) {
		
		associate.setAssociateId(Associate_IDX_COUNTER++);
		associates.put(associate.getAssociateId(),associate);
		return associate;
	}

	
	public Associate findOne(int associateId){
		return associates.get(associateId);
	}
	@Override
	public ArrayList<Associate> findsAll() {
		return  new ArrayList<>(associates.values());
		
	}
}
