package com.cg.payroll.services;

import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetail;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOimpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public class PayrollServicesimpl implements PayrollServices{

private AssociateDAO associatedao= new AssociateDAOimpl();
	

	public int acceptAssociateDetails(String firstName, String lastNmae, String email, String department,
			String designation, String pancard, int yearlyInvestment, int basicSalary, int epf, int companypf,
			int accountNumber, String bankName, String ifscCode)throws PayrollServicesDownException {
		Associate associate=new Associate(yearlyInvestment, firstName, lastNmae, department, designation, pancard, email, new BankDetail(accountNumber, bankName, ifscCode),new Salary(basicSalary, epf, companypf));
		associate=associatedao.save(associate);	
		return ((Associate) associate).getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFound{
		Associate associate = associatedao.findOne(associateId);
	
		if(associate==null)throw new AssociateDetailsNotFound("Associate Details not found");
		int netAmount;
		int basicSalary=associate.getSalary().getBasicSalary();
		int hra=(associate.getSalary().getBasicSalary()*30)/100;
		int other=(associate.getSalary().getBasicSalary()*20)/100;
		int personal=(associate.getSalary().getBasicSalary()*25)/100;
		int conveyence=(associate.getSalary().getBasicSalary()*25)/100;
		int gross=basicSalary+hra+other+personal+conveyence+associate.getSalary().getEpf()+associate.getSalary().getCompanyPf();
		int taxableAmount=(gross*12)-associate.getYearlyInvestmentUnder80C();
		System.out.println("Gross salary = "+taxableAmount/12);
		System.out.print("Net Salary = ");
		if(taxableAmount<250000) {
			return taxableAmount/12;
		}
		else if(taxableAmount>250000 && taxableAmount<=500000) {
			taxableAmount-=250000;
			netAmount =(taxableAmount-(taxableAmount*5)/100);
			return (250000+netAmount)/12;
			}
		else if(taxableAmount>500000 && taxableAmount<=100000) {
			taxableAmount-=500000;
			return (500000+(taxableAmount-((taxableAmount*20)/100+12500)))/12;
		}
		else {
			taxableAmount-=100000;
			return (1000000+(taxableAmount-((taxableAmount*30)/100+112500)))/12;
		}
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFound {
		Associate associate= associatedao.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFound("Associate Details not found");
		return associate;
	}
   @Override
	public  ArrayList<Associate> getAllAssociatesDetails() throws PayrollServicesDownException{
		return associatedao.findsAll();
	}	
}
