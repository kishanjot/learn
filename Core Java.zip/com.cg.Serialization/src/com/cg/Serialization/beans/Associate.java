package com.cg.Serialization.beans;

import java.io.Serializable;

public class Associate implements Serializable {
	
	private int  associateId,salary;
	private String firstName;
	private Address address;
	public Associate() {
		// TODO Auto-generated constructor stub
	}
	
	public Associate(int associateId, int salary, String firstName) {
		super();
		this.associateId = associateId;
		this.salary = salary;
		this.firstName = firstName;
	}
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Associate(int associateId, int salary, String firstName,
			Address address) {
		super();
		this.associateId = associateId;
		this.salary = salary;
		this.firstName = firstName;
		this.address = address;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", salary=" + salary
				+ ", firstName=" + firstName + ", address=" + address + "]";
	}
	
	
}
