package com.cg.ThreadOwn;

public class ResourcesRunnable implements Runnable{

	@Override
	public void run() {
		Thread t = Thread.currentThread();
		if(t.getName().equals("ABC"))
			System.out.println("ABC");
		else
			System.out.println("PQR");	
	}
}
