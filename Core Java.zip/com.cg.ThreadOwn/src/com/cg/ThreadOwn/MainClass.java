package com.cg.ThreadOwn;

public class MainClass {

	public static void main(String[] args) {
/*		MyThread th1 = new MyThread("ABC");
		MyThread th2 = new MyThread("PQR");
		
		th1.start();
		th2.start();
		Runnable r1 = new ResourcesRunnable();
		Thread th1 =  new Thread(r1, "ABC");
		Thread th2 =  new Thread(r1, "PQR");
		
		th1.start();
		th2.start();*/
		
		/*Annynomous Block
		 * Runnable r1 = new Runnable(){
			@Override
			public void run() {
			Thread t = Thread.currentThread();
			if(t.getName().equals("ABC"))
			for(int i=0;i<10;i++)
			System.out.println("th1");
			
			if(t.getName().equals("PQR"))
				for(int i=0;i<10;i++)
				System.out.println("th2");
			
			}
		};
		Thread th1 = new Thread(r1, "ABC");
		th1.start();
		Thread th2 = new Thread(r1, "PQR");
		th2.start();*/
		

/*		Lamda
 * 	Runnable r1 = ()->{
			Thread t = Thread.currentThread();
			if(t.getName().equals("ABC"))
			for(int i = 0;i< 11;i++)
				System.out.println("ABC "+i);
			
			if(t.getName().equals("PQR"))
				for(int i = 0;i< 11;i++)
					System.out.println("PQR "+i);
		} ;
		Thread th1 = new Thread(r1,"ABC");
		Thread th2 = new Thread(r1,"PQR");
		th1.start();
		th2.start();*/
		/*Lesser code
		 * Runnable r1 = ()->{
			System.out.println("OO");
		};
		Thread t = new Thread(r1);
		t.start();*/
		
		/*Lesser Code
		 *  Runnable r1 = ()->{
				System.out.println("OO");
			};
			new Thread(r1).start();*/

	}

}
