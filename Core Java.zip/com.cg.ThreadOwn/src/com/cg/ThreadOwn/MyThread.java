package com.cg.ThreadOwn;

public class MyThread extends Thread{

	
	public MyThread(String name) {
		super(name);
	}

	@Override
	public void run() {
		if(this.getName().equals("ABC"))
			for(int i = 0;i <=10;i++)
				System.out.println("th1");
		
		if(this.getName().equals("PQR"))
			for(int i = 0;i <=10;i++)
				System.out.println("th2");
	}
}
