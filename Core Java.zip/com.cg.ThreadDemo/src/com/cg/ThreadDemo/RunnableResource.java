package com.cg.ThreadDemo;

public class RunnableResource implements Runnable{

	@Override
	public void run() {
		Thread t = Thread.currentThread();
		if(t.getName().equals("abc"))
			for(int i=0;i<=10;i++){
				System.out.println("* "+i);
			}
		if(t.getName().equals("pqr"))
			for(int i=0;i<=10;i++){
				System.out.println("@ "+i);
			}
	}
}