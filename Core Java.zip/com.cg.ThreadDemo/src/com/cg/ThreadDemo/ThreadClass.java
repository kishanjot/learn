package com.cg.ThreadDemo;
public class ThreadClass extends Thread {
	public ThreadClass(String name) {
		super(name);
	}
	@Override
	public void run() {
		if(this.getName().equals("Odd"))
			for(int i=1;i<=100;i+=2)
				System.out.println("Odd thread ka "+i);
		
		if(this.getName().equals("Even"))
			for(int i =2;i<=100;i+=2)
				System.out.println("Even thread ka "+i);
	}
}