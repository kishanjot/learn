package com.cg.ThreadDemo;

public class MainClasss {

	public static void main(String[] args) {
/*		ThreadClass th1 = new ThreadClass("Odd");
			ThreadClass th2 = new ThreadClass("Even");
			th1.start();
			th2.start();
		RunnableResource r1 = new  RunnableResource();
		Thread th1 = new Thread(r1, "abc");
		Thread th2 = new Thread(r1, "pqr");
		th1.start();
		th2.start();
		try {
			th1.join();
			th1.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Method main ends!!");
		*/
		
		Runnable runnableResource = () ->{
			for(int i = 0; i<10; i++)
				System.out.println("Tick "+i);
		};
		Thread th1 = new Thread(runnableResource);
		th1.start();	
	}
}
