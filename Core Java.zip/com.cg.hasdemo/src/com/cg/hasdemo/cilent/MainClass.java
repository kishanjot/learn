package com.cg.hasdemo.cilent;

import com.cg.hasdemo.beans.Address;
import com.cg.hasdemo.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		Address address=new Address(125648, "PUNE", "Maharasta", "India");
		
		
		
		Customer customer=new Customer(101,"Somnath","Dey",address);
		
		/*Address address1=customer.getAddress();
		System.out.println(address1.getCity());*/
		
		/*System.out.println(customer.getCustomerId());
		System.out.println(customer.getFirstName());
		System.out.println(customer.getLastName());
		System.out.println(address.getCity());
		System.out.println(address.getCountry());
		System.out.println(address.getPincode());
		System.out.println(address.getState());*/
		
		/*
		System.out.println(customer.getAddress().getCity());
		*/
		
		customer.setAddress(new Address(21332,"x","y","z"));
		System.out.println(customer.getAddress().getCountry());
	}
}
