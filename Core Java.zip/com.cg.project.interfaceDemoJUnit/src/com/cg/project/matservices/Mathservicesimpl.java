package com.cg.project.matservices;

import com.cg.project.exceptions.InvalidNumberRangeException;

public class Mathservicesimpl implements Mathservices{

	@Override
	public int addNum(int num1, int num2) throws InvalidNumberRangeException {
		if(num1<0||num2<0) throw new InvalidNumberRangeException("Enter positive number");
		return num1+num2;
	}

	@Override
	public int subNum(int num1, int num2) throws InvalidNumberRangeException {
		if(num1<0||num2<0) throw new InvalidNumberRangeException("Enter positive number");
		return num1-num2;
	}

	@Override
	public int mulNum(int num1, int num2) throws InvalidNumberRangeException {
		if(num1<0||num2<0) throw new InvalidNumberRangeException("Enter positive number");
		return num1*num2;
	}


}
