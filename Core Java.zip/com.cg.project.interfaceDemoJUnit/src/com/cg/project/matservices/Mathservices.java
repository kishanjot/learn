package com.cg.project.matservices;
import com.cg.project.exceptions.InvalidNumberRangeException;
public interface Mathservices {
	public abstract int addNum(int num1,int num2) throws InvalidNumberRangeException;
	abstract int subNum(int num1,int num2)throws InvalidNumberRangeException;
	int mulNum(int num1,int num2) throws InvalidNumberRangeException;
}