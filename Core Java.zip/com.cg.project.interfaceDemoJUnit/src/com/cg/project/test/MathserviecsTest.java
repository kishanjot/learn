package com.cg.project.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.matservices.Mathservices;
import com.cg.project.matservices.Mathservicesimpl;

public class MathserviecsTest {

	static Mathservices mathServices;
	@BeforeClass
	public static void setUpTestEnv(){
		mathServices = new Mathservicesimpl();
	}
	@Before
	public void setupMockDataForTest(){
		
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testAddNumberForFirstNoInvalid() throws InvalidNumberRangeException{
		mathServices.addNum(-100, 200);
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testAddNumberForSecondNoInvalid() throws InvalidNumberRangeException{
		mathServices.addNum(100, -200);
	}
	@Test
	public void testAddNumberForBothValid() throws InvalidNumberRangeException{
		int expectedAns = 300;
		int actualAns= mathServices.addNum(100, 200);
		Assert.assertEquals(expectedAns, actualAns);
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testSubNumberForFirstInvalid() throws InvalidNumberRangeException{
		mathServices.subNum(-100,200);
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testSubNumberForSecondInvalid() throws InvalidNumberRangeException{
		mathServices.subNum(100,-200);
	}
	@Test
	public void testSubNumberForBothValid() throws InvalidNumberRangeException{
		int acuatlAns=mathServices.subNum(200,100);
		int expectedAns=100;
		Assert.assertEquals(expectedAns, acuatlAns);
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testMulNumberForFirstInvalid() throws InvalidNumberRangeException{
		mathServices.mulNum(-100,200);
	}
	@Test(expected = InvalidNumberRangeException.class)
	public void testMulNumberForSecondInvalid() throws InvalidNumberRangeException{
		mathServices.mulNum(100,-200);
	}
	@Test
	public void testMulNumberForBothValid() throws InvalidNumberRangeException{
		int actualAns=mathServices.mulNum(100,200);
		int expectedAns = 20000;
		Assert.assertEquals(expectedAns, actualAns);
	}
	@After
	public void tearDownMockDataForTest(){
		
	}
	@AfterClass
	public static void tearDownTestEnv(){
		mathServices = null;
	}

}
