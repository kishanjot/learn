package com.cg.project.cilent;


import com.cg.project.exceptions.InvalidNumberRangeException;
import com.cg.project.matservices.Mathservices;
import com.cg.project.matservices.Mathservicesimpl;

public class MainClass {
public static void main(String[] args) throws InvalidNumberRangeException{		
		Mathservices service =  new Mathservicesimpl();
		System.out.println(service.mulNum(11, 10));
		try {
			System.out.println(service.addNum(-10, 20));
			System.out.println(service.subNum(10, 20));
		} catch (InvalidNumberRangeException e) {
			e.printStackTrace();
		}
	}
}
