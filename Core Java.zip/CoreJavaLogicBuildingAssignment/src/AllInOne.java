
public class AllInOne {

	public static void main(String[] args) {
		int[] numList={12,11,121,153,3};
		int i,oddCount=0,evenCount=0;
		int pallindromeCount=0,armstrongCount=0;
		for(i=0;i<numList.length;i++){
			if(numList[i]%2!=0){
				oddCount++;
			}
			else{
				evenCount++;
			}
			int n=numList[i],y,newNo=0,oldNo;
			oldNo=n;
			while(n!=0){
				y=n%10;
				newNo=newNo+y*y*y;
				n/=10;
			}
			if(oldNo==newNo)
				armstrongCount++;			
			int num=numList[i],oldNum,z,newNum=0;
			oldNum=num;
			while(num!=0){
				z=num%10;
				newNum=newNum*10+z;
				num/=10;
			}
			if(oldNum==newNo)
				pallindromeCount++;
		}
		System.out.println("Number of even number = "+evenCount);
		System.out.println("Number of odd number = "+oddCount);
		System.out.println("Number of armstrong number = "+armstrongCount);
		System.out.println("Number of pallindrome number = "+pallindromeCount);
	}

}
