public class MatrixMultiplication {
	public static void main(String[] args) {
		int[][] numList1={{1,2},{3,4}};
		int[][]numList2={{3,4},{4,5}};
		int[][] result= new int[2][2];
		int i,j,k;
		for(i=0;i<numList1.length;i++){
			for(j=0;j<numList2.length;j++){
				for(k=0;k<numList2.length;k++){
					result[i][j]=result[i][j]+numList1[i][k]*numList2[k][j];
				}
			}
		}
		for(i=0;i<numList1.length;i++){
			for(j=0;j<numList2.length;j++){
				System.out.print(" "+result[i][j]);
			}
			System.out.println("");
		}
	}
}


