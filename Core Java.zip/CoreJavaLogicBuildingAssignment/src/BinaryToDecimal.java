
public class BinaryToDecimal {

	public static void main(String[] args) {
		int binNo[]={1,0,0,1};
		int i,j,z=0,s=0;
		for(i=0;i<=binNo.length-1;i++){
			if(binNo[i]==1){
				int x=1;
				for(j=i+1;j<binNo.length;j++){
					x=x*2;
				}		
				z=x;
			}
			s=s+z;
		}
			System.out.println(""+s);
	}
}



