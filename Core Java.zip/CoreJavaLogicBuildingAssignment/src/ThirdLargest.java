
public class ThirdLargest {

	public static void main(String[] args) {
		int []numList={5,4,3,2,1};//descending order
		int j=0,i;
		int max=0;
		while(j<3){
			max=numList[j];
			for(i=j;i<numList.length;i++){
				if(numList[i]>max){
					max=numList[i];
				}
			}
			j++;
		}
		System.out.println(max);
	}
}
