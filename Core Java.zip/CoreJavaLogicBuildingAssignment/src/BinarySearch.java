
public class BinarySearch {

	public static void main(String[] args) {
		int[] numList={2,5,8,12,16};
		int searchElement=8;
		int low=0;
		int high=numList.length-1;
		int mid=(low+high)/2;
	
		if(mid==searchElement){
			System.out.println("Element found is "+numList[mid]);
		}
		else{
			while(low<high){
				if(searchElement<numList[mid]){
					high=mid;
					mid=(low+high)/2;
				}
				else{
					low=mid;
					mid=(low+high)/2;
				}
			}
		}
	}
}
