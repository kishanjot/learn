public class ArrayForm {

	public static void main(String[] args) {
		int[] numList={1,2,3,4,5,6,7,8,9};
		int []requiredListIndex={1,3,5,7,8,6,4,2,0};
		int[] temp=new int[10];
		int i;
		for(i=0;i<numList.length;i++){
			temp[requiredListIndex[i]]=numList[i];
		}
		for(i=0;i<numList.length;i++){
			System.out.print(" "+temp[i]);
		}
	}
}
