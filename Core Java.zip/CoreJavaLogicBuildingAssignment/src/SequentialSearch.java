
public class SequentialSearch {

	public static void main(String[] args) {
		int []numList={1,2,3,4,5};
		int i,count=0;
		int searchElement=8;
		for(i=0;i<numList.length;i++){
			if(searchElement==numList[i]){
				count++;
			}
		}
		if(count>0){
			System.out.println("Element Found");
		}
		else{
			System.out.println("Element Not Found");
		}
	}

}
