
public class SwapNumber {

	public static void main(String[] args) {
		int num1=2,num2=3;
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("AFTER SWAPPING: num1= "+num1+" num2= "+num2);
	}
}
