
public class DecimalToBinary {

	public static void main(String[] args) {
		int num=121,i=0,j;
		int arr[] = new int[20];
		while(num!=0){
			if(num%2==0){
				arr[i]=0;
				i++;
			}
			else{
				arr[i]=1;
				i++;
			}
			num/=2;
		}
		for(j=i-1;j>=0;j--){
			System.out.print(arr[j]);
		}
	}
}
