
public class BinaryPallindrome {

	public static void main(String[] args) {
		int num=121,i=0,j;
		int originalNumber=num;
		int arr[] = new int[20];
		while(num!=0){
			if(num%2==0){
				arr[i]=0;
				i++;
			}
			else{
				arr[i]=1;
				i++;
			}
			num/=2;
		}
		System.out.print("Binary form of the number "+originalNumber+" is ");
		for(j=i-1;j>=0;j--){
			System.out.print(arr[j]);
		}
		
		int oldNo,y,newNo=0;
		oldNo=originalNumber;
		while(originalNumber!=0){
			y=originalNumber%10;
			newNo=newNo*10+y;
			originalNumber/=10;
		}
		System.out.print(" And it is");
		if(oldNo==newNo)
			System.out.println(" also Pallindrome Number");
		else
			System.out.println(" not Pallindrome Number");

	}

}
