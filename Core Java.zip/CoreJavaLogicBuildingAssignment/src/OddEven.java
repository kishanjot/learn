
public class OddEven {

	public static void main(String[] args) {
	//	int startRange=5;
	//	int endRange=10;
		int []numList={5,6,7,8,9,10};
		int []even=new int[5];
		int []odd=new int[5];
		int i,j=0,k=0;
		for(i=0;i<numList.length;i++){
			if(numList[i]%2==0){
				even[j]=numList[i];
				j++;
			}
			else{
				odd[k]=numList[i];
				k++;
			}
		}
		System.out.print("Even are: ");
		for(i=0;i<j;i++){
			System.out.print(" "+even[i]);
		}
		System.out.println("");
		System.out.print("Odd are: ");
		for(i=0;i<k;i++){
			System.out.print(" "+odd[i]);
		}
	}
}
