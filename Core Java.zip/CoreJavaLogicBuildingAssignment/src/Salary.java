public class Salary {
	public static void main(String[] args) {
		int experienceInYear=2,empDesignationId=1,bonus=0;
		switch(empDesignationId){
		case 1:{
			switch(experienceInYear){
			case 1:{
				bonus=100;
				break;
			}
			case 2:{
				bonus=200;
				break;
			}
			case 3:{
				bonus=300;
				break;
			}
			default:
				System.out.println("Not Available");
			}
			break;
		}
		default:
			System.out.println("Designation Not Found");
		}
		System.out.println("Bonus for empDesigmationId "+empDesignationId+" for "+experienceInYear+"  years of experience is "+bonus);
	}
}