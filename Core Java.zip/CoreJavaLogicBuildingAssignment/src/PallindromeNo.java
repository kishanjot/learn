public class PallindromeNo {
	public static void main(String[] args) {
		int n=121,oldNo,y,newNo=0;
		oldNo=n;
		while(n!=0){
			y=n%10;
			newNo=newNo*10+y;
			n/=10;
		}
		System.out.println(newNo);
		if(oldNo==newNo)
			System.out.println("Pallindrome Number");
		else
			System.out.println("Not Pallindrome Number");
	}
}
