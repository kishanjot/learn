
public class Factorial {

	public static void main(String[] args) {
		int num=5;
		int i,fac=1;
		for(i=1;i<=num;i++){
			fac=fac*i;
		}
		System.out.println(fac);
	}

}
