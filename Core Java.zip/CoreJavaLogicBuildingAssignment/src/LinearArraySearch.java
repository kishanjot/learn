
public class LinearArraySearch {

	public static void main(String [] args){

		int i=0,count=0;
		int numList[]={1,2,3,4,5,6,7,8,9,10};
		while(i<numList.length){
			if(numList[i]==5)
				count++;
			i++;
		}
		if(count>0)
			System.out.println("Number found");
		else
			System.out.println("Number not found");
	}
}
