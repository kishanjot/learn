
public class FibonacciSeries {

	public static void main(String[] args) {
		int i, a,b,c,numTerms;
		a=0;
		b=1;
		numTerms=5;
		System.out.println(""+a);
		System.out.println(""+b);
		for(i=0;i<numTerms;i++){
			c=a+b;
			a=b;
			b=c;
			System.out.println(""+c);
		}
	}
}
