
public class SelectionSort {

	public static void main(String[] args) {
		int [] numList={64,25,12,22,11};
		int i,j,temp,minindex=0;
			for(i=0;i<numList.length-1;i++){
				int min=numList[i];
			for(j=i+1;j<numList.length;j++){
				if(min>numList[j]){
					minindex=j;
					min=numList[j];
				}
			}
			temp=numList[i];
			numList[i]=numList[minindex];
			numList[minindex]=temp;
			}
			for(i=0;i<numList.length;i++){
				System.out.print(" "+numList[i]);
			}
		}
	}

