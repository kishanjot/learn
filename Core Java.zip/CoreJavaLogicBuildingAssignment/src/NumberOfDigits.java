public class NumberOfDigits {
	public static void main(String[] args) {
			int[]  numList={1,11,111};
			int i;
			int oneDigit=0,twoDigit=0,threeDigit=0;
			for(i=0;i<numList.length;i++){
				if(numList[i]>0 && numList[i]<10){
					oneDigit++;
				}
				if(numList[i]>9 && numList[i]<100){
					twoDigit++;
				}
				if(numList[i]>99 && numList[i]<1000){
					threeDigit++;
				}
			}
			System.out.println("Number of one digit number = "+oneDigit);
			System.out.println("Number of two digit number = "+twoDigit);
			System.out.println("Number of three digit number = "+threeDigit);
	}
}
