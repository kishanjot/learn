
public class InsertionSort {

	public static void main(String[] args) {
		int[] numList={4,3,2,10,12,1,5,6};
		int i,j,temp;
		for(i=0;i<numList.length;i++){
			for(j=0;j<i;j++){
				if(numList[i]<numList[j]){
					temp=numList[i];
					numList[i]=numList[j];
					numList[j]=temp;
				}
			}
		}
		for(i=0;i<numList.length;i++){
			System.out.print(" "+numList[i]);
		}
	}

}
