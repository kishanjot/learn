package com.cg.banking.beans;

public class Account {
	private int customerId ;
	private String firstName , lastName ,	emailId ,	pancardNo , dateOfBirth,
                            	mobileNo , adharNo ;


}
