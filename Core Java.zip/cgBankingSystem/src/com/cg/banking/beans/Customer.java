package com.cg.banking.beans;

public class Customer {
	private int customerId;
	private String firstName,lastName ,mobileNo ,  emailId ,adharNo,pancardNo,
							dateOfBirth ;
}
