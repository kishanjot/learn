package com.cg.banking.beans;

public class Transaction {
	 private int transactionId ,
	 timeStamp,
	amount,
	transactionType ,
	transactionLocation ,
	modeOfTransaction ,
	transactionStatus;
}
