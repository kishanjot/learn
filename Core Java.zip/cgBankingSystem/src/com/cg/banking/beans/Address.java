package com.cg.banking.beans;

public class Address {
	private String city ,state ,pinCode, country;
}
