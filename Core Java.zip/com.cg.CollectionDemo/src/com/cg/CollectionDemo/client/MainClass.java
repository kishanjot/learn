package com.cg.CollectionDemo.client;

import com.cg.CollectionDemo.ListClass.ListClassesDemo;
import com.cg.CollectionDemo.ListClass.SetClassDemo;
import com.cg.CollectionDemo.ListClass.setHashDemo;

public class MainClass {

	public static void main(String[] args) {
		setHashDemo. MapClassWork();

	}

}
