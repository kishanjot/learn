package com.cg.CollectionDemo.beans;

public class Associate implements Comparable<Associate>{
	private int associateId,Salary;
	private String firstName;

	public Associate() {}

	public Associate(int associateId, int salary, String firstName) {
		super();
		this.associateId = associateId;
		Salary = salary;
		this.firstName = firstName;
	}

	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Salary;
		result = prime * result + associateId;
		result = prime * result
				+ ((firstName == null) ? 0 : firstName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (Salary != other.Salary)
			return false;
		if (associateId != other.associateId)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", Salary=" + Salary
				+ ", firstName=" + firstName + "]";
	}

	@Override
	public int compareTo(Associate o) {
		return this.firstName.compareTo(o.firstName);
	}



}
