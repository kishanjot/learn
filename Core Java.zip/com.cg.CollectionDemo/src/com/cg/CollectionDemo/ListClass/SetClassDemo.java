package com.cg.CollectionDemo.ListClass;

import java.util.ArrayList;
import java.util.HashSet;

import com.cg.CollectionDemo.beans.Associate;

public  class SetClassDemo {
	public static void HashSetDemo(){
		HashSet<Associate> associateSet= new HashSet<>();
		associateSet.add(new Associate(101, 11000, "Satish"));
		associateSet.add(new Associate(102, 12000, "Kumar"));
		associateSet.add(new Associate(104, 14000, "Nilesh"));
		associateSet.add(new Associate(103, 13000, "Rakesh"));
		associateSet.add(new Associate(103, 13000, "Rakesh"));
		
		for (Associate associate : associateSet) {
			System.out.println(associate);
		}
	}
}
