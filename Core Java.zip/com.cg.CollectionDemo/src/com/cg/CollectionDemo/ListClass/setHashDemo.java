package com.cg.CollectionDemo.ListClass;

import java.util.HashMap;

import com.cg.CollectionDemo.beans.Associate;

public class setHashDemo {
	public static void MapClassWork(){

	HashMap<Integer, Associate> associate= new HashMap<>();
	
	
	associate.put(101,new Associate(101, 11000, "Satish"));
	associate.put(102,new Associate(102, 12000, "Kumar"));
	associate.put(103,new Associate(104, 14000, "Nilesh"));
	associate.put(104,new Associate(103, 13000, "Rakesh"));
	
	System.out.println(associate.get(102));
	
}
}