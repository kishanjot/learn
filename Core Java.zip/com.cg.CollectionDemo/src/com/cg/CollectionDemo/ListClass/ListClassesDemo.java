package com.cg.CollectionDemo.ListClass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.cg.CollectionDemo.beans.Associate;

public class ListClassesDemo {
	public static void  arrayListClassWork() {
		ArrayList<String> strList = new ArrayList<>();
		strList.add("Somnath");
		strList.add("Nilesh");
		strList.add("Arnav");
		strList.add("Rahul");
		strList.add("Ritesh");
		
		System.out.println(strList.contains("Somnath"));
		System.out.println(strList.indexOf("Arnav"));
		
		Collections.sort(strList);
		
	
		for (String name : strList) {
			System.out.println(name);
		}
		
		ArrayList<Associate> associateList= new ArrayList<>();
		associateList.add(new Associate(101, 11000, "Satish"));
		associateList.add(new Associate(102, 12000, "Kumar"));
		associateList.add(new Associate(104, 14000, "Nilesh"));
		associateList.add(new Associate(103, 13000, "Rakesh"));
		
		Associate associateToBeSearch= new Associate(102, 12000, "Kumar");
		
		System.out.println(associateList.indexOf(associateToBeSearch));
		System.out.println(associateList.contains(associateToBeSearch)); 
		
		Collections.sort(associateList);
		
		Collections.sort(associateList,	new AssociateComparator());
		for (Associate associate : associateList) {
			System.out.println(associate);
			/*if(associate.getAssociateId()==103 && associate.getFirstName().equals("Nilesh"));
				*/
		}
	}

	
}
