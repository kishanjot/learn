package com.capgemini.takehome.exceptions;
public class InvalidCodeException extends RuntimeException {
}
