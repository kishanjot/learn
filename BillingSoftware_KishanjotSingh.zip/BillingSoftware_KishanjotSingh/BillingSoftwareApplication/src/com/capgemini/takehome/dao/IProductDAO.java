//-------Interface of DAO Layer------//
package com.capgemini.takehome.dao;
import com.capgemini.takehome.bean.Product; //Product Class Is Imported
public interface IProductDAO {
Product save(Product product);
Product getProductDetails(int productCode); //Get Product Details Method to get output
}
