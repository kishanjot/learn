package com.capgemini.takehome.bean;
public class Product {
	private int productId;
	private String name;
	private String category;		//Variables Declared Here
	private int productPrice;
	private String description;
	Product(){} //Default Constructor Is Created
	
					//-------Parameterized Constructor Created------//
	public Product(int productId, String name, String category, int productPrice) {
		super();
		this.productId = productId;
		this.name = name;				
		this.category = category;
		this.productPrice = productPrice;
	}
	public Product(int productId, String name, String category, int productPrice, String description) {
		super();
		this.productId = productId;
		this.name = name;
		this.category = category;
		this.productPrice = productPrice;
		this.description = description;
	}
										//-------GETTERS AND SETTERS------//
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	//-------HASHCODE------//
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + productId;
		result = prime * result + productPrice;
		return result;
	}
	//-------EQUALS------//
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (productId != other.productId)
			return false;
		if (productPrice != other.productPrice)
			return false;
		return true;
	}
	
	//-------To String------//
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", category=" + category + ", productPrice="
				+ productPrice + ", description=" + description + "]";
	}
	
}