//-------Service Layer------//
package com.capgemini.takehome.service;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;
import com.capgemini.takehome.exceptions.InvalidCodeException;
import com.capgemini.takehome.exceptions.ProductNotFoundException;
public class ProductService implements IProductService{
	private IProductDAO serviceDao=new ProductDAO(); 

	@Override
	public Product getProductDetails(int productCode) throws ProductNotFoundException,InvalidCodeException{
		if(Integer.toString(productCode).length()!=4) //Max 4 Digits are accepted
			throw new InvalidCodeException();
		Product product=serviceDao.getProductDetails(productCode);
		if(product==null) //If not a valid entry
			throw new ProductNotFoundException();
		return product;
	}
}
