//-------Main Class------//
package com.capgemini.takehome.ui;
import java.util.Scanner;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exceptions.InvalidCodeException;
import com.capgemini.takehome.exceptions.ProductNotFoundException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;
public class Client {
	IProductService services=new ProductService(); 
	Product productdetails=services.getProductDetails(1001);
	//  System.out.println("Product Details Are :"+productdetails);

	static Scanner sc=new Scanner (System.in);
	static ProductService prodSer=new ProductService();
	static void generateBill()
	{
		System.out.println("Please Enter Product Details :  ");
		System.out.println("Product code:\n  1. Iphone(1001) \n 2. LED TV(1002) \n 3. Teddy(1003) \n 4. Telescope (1004)");
		int code=sc.nextInt();
		System.out.println("Enter the Quantity:");

		int quan=sc.nextInt();
		//----TRY AND CATCH BLOCK TO CATCH EXCEPTIONS--//
		try {
			System.out.println(prodSer.getProductDetails(code));
			System.out.println("Total = "+prodSer.getProductDetails(code).getProductPrice()*quan);
		}
		catch(InvalidCodeException e)
		{
			System.out.println("Invalid Product Code, Please Try Again");
		}
		catch(ProductNotFoundException e)
		{
			System.out.println("Product Not Found, Please Try Again");
		}
	}

	public static void main(String args[])
	{
		int choice;

		while(true)
		{
			System.out.println("******WELCOME TO RELIANCE DIGITAL MARKET******");
			System.out.println("Press 1 To Generate Bill");
			System.out.println("Press 2 To Exit");
			choice=sc.nextInt();
			if(choice==1)
			{
				generateBill();

			}
			else if(choice==2)
			{
				System.exit(0);
			}
		}
	}

}

